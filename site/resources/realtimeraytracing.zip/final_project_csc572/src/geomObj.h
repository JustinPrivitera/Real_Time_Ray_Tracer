#pragma once

#include "geom_objs/light_source.h"
#include "geom_objs/plane.h"
#include "geom_objs/rectangle.h"
#include "geom_objs/shape.h"
#include "geom_objs/sphere.h"
